/**************************************************************************************************
 *
 *                                    Wifi / NTP Stuff - Dec19
 *             
 *  
 **************************************************************************************************/
 

// Wifi libraries (for both ESP8266 and ESP32)
  #if defined(ESP8266)
    #include <ESP8266WiFi.h>          //https://github.com/esp8266/Arduino
  #else
    #include <WiFi.h>                 //https://github.com/esp8266/Arduino
  #endif
  #include <DNSServer.h>
  #if defined(ESP8266)
    #include <ESP8266WebServer.h>
  #else
    #include <WebServer.h>
  #endif
  #include <WiFiManager.h>            // https://github.com/zhouhan0126/WIFIMANAGER-ESP32
  
  
// check which type of esp is being used (more info - https://www.youtube.com/watch?v=1WqyMF6Jcss )
  #if defined(ESP8266)
    const String ESPType = "ESP8266";
  #elif defined(ESP32)
    const String ESPType = "ESP32";
  #else
    #error "Not using ESP8266 or ESP32"
  #endif

// define web server
  #if defined(ESP8266)
    ESP8266WebServer server(ServerPort);
  #else
    WebServer server(ServerPort);     
  #endif


// time from NTP 
  #include <TimeLib.h>
  unsigned int localPort = 8888;               // Just an open port we can use for the UDP packets coming back in
  char timeServer[] = "uk.pool.ntp.org"; 
  const int NTP_PACKET_SIZE = 48;              // NTP time stamp is in the first 48 bytes of the message
  byte packetBuffer[NTP_PACKET_SIZE];          // buffer to hold incoming and outgoing packets
  WiFiUDP NTPUdp;                              // A UDP instance to let us send and receive packets over UDP
  const int timeZone = 0;                      // timezone (0=GMT)
  String DoW[] = {"","Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
  // How often to resync the time (under normal and error conditions)
    const int _resyncSeconds = 3600;           // 3600 = 1 hour
    const int _resyncErrorSeconds = 120;
  boolean NTPok = 0;                           // Flag if NTP is curently connecting ok
  time_t getNTPTime();


// --------------------------- E N D -----------------------------
