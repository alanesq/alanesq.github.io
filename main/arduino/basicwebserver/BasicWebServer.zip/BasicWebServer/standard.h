/**************************************************************************************************
 *
 *                                      Standard procedures - Dec19
 *             
 *  
 **************************************************************************************************/


//-----------------------------------------------------------------------------
//        send an NTP request to the time server at the given address
//-----------------------------------------------------------------------------

// code from https://github.com/RalphBacon/No-Real-Time-Clock-RTC-required---use-an-NTP

void sendNTPpacket(const char* address) {
  
  // set all bytes in the buffer to 0
  memset(packetBuffer, 0, NTP_PACKET_SIZE);
  // Initialize values needed to form NTP request
  // (see URL above for details on the packets)
  packetBuffer[0] = 0b11100011;   // LI, Version, Mode
  packetBuffer[1] = 0;            // Stratum, or type of clock
  packetBuffer[2] = 6;            // Polling Interval
  packetBuffer[3] = 0xEC;         // Peer Clock Precision
  // 8 bytes of zero for Root Delay & Root Dispersion
  packetBuffer[12] = 49;
  packetBuffer[13] = 0x4E;
  packetBuffer[14] = 49;
  packetBuffer[15] = 52;

  // all NTP fields have been given values, now you can send a packet requesting a timestamp:
  // Note that Udp.begin will request automatic translation (via a DNS server) from a
  // name (eg pool.ntp.org) to an IP address. Never use a specific IP address yourself,
  // let the DNS give back a random server IP address
  NTPUdp.beginPacket(address, 123); //NTP requests are to port 123

  // Get the data back
  NTPUdp.write(packetBuffer, NTP_PACKET_SIZE);

  // All done, the underlying buffer is now updated
  NTPUdp.endPacket();
  
}


//-----------------------------------------------------------------------------
//                           -British Summer Time check
//-----------------------------------------------------------------------------

// code from https://my-small-projects.blogspot.com/2015/05/arduino-checking-for-british-summer-time.html

boolean IsBST()
{
    int imonth = month();
    int iday = day();
    int hr = hour();
    
    //January, february, and november are out.
    if (imonth < 3 || imonth > 10) { return false; }
    //April to September are in
    if (imonth > 3 && imonth < 10) { return true; }

    // find last sun in mar and oct - quickest way I've found to do it
    // last sunday of march
    int lastMarSunday =  (31 - (5* year() /4 + 4) % 7);
    //last sunday of october
    int lastOctSunday = (31 - (5 * year() /4 + 1) % 7);
        
    //In march, we are BST if is the last sunday in the month
    if (imonth == 3) { 
      
      if( iday > lastMarSunday)
        return true;
      if( iday < lastMarSunday)
        return false;
      
      if (hr < 1)
        return false;
              
      return true; 
  
    }
    //In October we must be before the last sunday to be bst.
    //That means the previous sunday must be before the 1st.
    if (imonth == 10) { 

      if( iday < lastOctSunday)
        return true;
      if( iday > lastOctSunday)
        return false;  
      
      if (hr >= 1)
        return false;
        
      return true;  
    }

}


// ----------------------------------------------------------------
//         -time and date from NTP, return as a string
// ----------------------------------------------------------------

String currentTime(){

   time_t t=now();     // get current time from NTP

   // hour - Adjust for British Summer Time
     byte thour = hour(t);
     if (IsBST()) thour = thour + 1;

   String ttime = String(thour) + ":" ;                                               // hours
   if (minute(t) < 10) ttime += "0";                                                  // minutes
   ttime += String(minute(t)) + " ";
   ttime += DoW[weekday(t)] + " ";                                                    // day of week
   ttime += String(day(t)) + "/" + String(month(t)) + "/" + String(year(t)) + " ";    // date

   return ttime;

}


// ----------------------------------------------------------------
//                      -log a system message  
// ----------------------------------------------------------------

void log_system_message(String smes) {

  //scroll old log entries up 
    for (int i=0; i < LogNumber; i++){
      system_message[i]=system_message[i+1];
    }

  // add the message
    system_message[LogNumber] = currentTime() + " - " + smes;
  
  // also send message to serial port
    Serial.println(system_message[LogNumber]);
}



// ----------------------------------------------------------------
//                      -wifi initialise  
// ----------------------------------------------------------------

void startWifiManager() {

  // WiFiManager - connect to wifi with stored settings
    WiFiManager wifiManager;                                     // Local intialization 
    if (resetESP == 1) {
      Serial.println("--- Clearing stored wifi settings ---");
      wifiManager.resetSettings();                               // reset stored wifi settings 
    }
    wifiManager.setTimeout(240);                                 // sets timeout for configuration portal (240=4 mins)
    Serial.println("Starting Wifi Manager");
    if(!wifiManager.autoConnect( "ESPconfig" , "12345678" )) {   // Activate wifi - access point name and password are set here (password must be 8 characters for some reason)
      // Failed to connect to wifi and access point timed out so reboot and try again
      Serial.println("failed to connect to wifi and access point timed out so rebooting to try again");
      delay(3000);
      ESP.restart();                                             // reboot and try again
      delay(5000);                                               // restart will fail without this delay
    }

    // Now connected to Wifi network
    if (WiFi.status() == WL_CONNECTED) {
      wifiok = 1;     // flag wifi now ok
      log_system_message("Wifi connected");                    
    } else {
      wifiok = 0;     // flag wifi now ok
      log_system_message("Problem with Wifi connection");     // log system message
    }

  // turn off sleep mode for esp8266
  #if defined(ESP8266)
    WiFi.setSleepMode(WIFI_NONE_SLEEP);     // Stops wifi turning off (if on causes wifi to drop out randomly)
  #endif
}

// ----------------------------------------------------------------
//                         -header (html) 
// ----------------------------------------------------------------

// HTML at the end of each web page
//
//    refresh = how often to auto refresh the page in seconds  (not usually used as jscript a better option)
//    more info on html here - https://randomnerdtutorials.com/esp8266-web-server/


String webheader(int refresh) {

    if ( (refresh < 0) || (refresh > 1000) ) refresh = 0;      // verify valid refresh rate

    String message = 
      "<!DOCTYPE html>\n"
      "<html>\n"
         "<head>\n"
           "<meta name='viewport' content='width=device-width, initial-scale=1.0'>\n"
           "<link rel=\'icon\' href=\'data:,\'>\n"
           "<title>" + stitle + "</title>\n";
           // Auto refresh page if requested
              if (refresh > 0) message += "<meta http-equiv='refresh' content='" + String(refresh) + "' />\n";
              message +=
           "<style>\n"                             /* Settings here for the top of screen menu appearance */
             "ul {list-style-type: none; margin: 0; padding: 0; overflow: hidden; background-color: rgb(128, 64, 0);}\n"
             "li {float: left;}\n"
             "li a {display: inline-block; color: white; text-align: center; padding: 30px 20px; text-decoration: none;}\n"
             "li a:hover { background-color: rgb(100, 0, 0);}\n"
           "</style>\n"
         "</head>\n"
         "<body style='color: rgb(0, 0, 0); background-color: yellow; text-align: center;'>\n"
           "<ul>\n"                  
             "<li><a href='/'>Home</a></li>\n"                      /* home menu button */
             "<li><a href='/log'>Log</a></li>\n"                    /* log menu button */
             "<h1>" + red + stitle + endcolour + "</h1>\n"          /* display the project title in red */
           "</ul>\n";

    return message;
    
}


// ----------------------------------------------------------------
//                             -footer (html)
// ----------------------------------------------------------------

// HTML at the end of each web page


String webfooter(void) {

     // NTP server link status
            String NTPtext = "NTP Link "; 
            if (NTPok == 1) NTPtext += "OK";
            else NTPtext += "down";

      String message = 
      
             "<br>\n" 
             
           /* Status display at bottom of screen */
             "<div style='text-align: center;background-color:rgb(128, 64, 0)'>\n" 
                "<small>" + red + 
                  stitle + " " + sversion + " | Memory:" + String(ESP.getFreeHeap()) + " | Wifi: " + String(WiFi.RSSI()) + "dBm" + " | " + NTPtext + 
                endcolour + "</small>\n" 
             "</div>\n" 
               
           /* end of HTML */  
             "</body>\n" 
             "</html>\n";


      return message;

}



// ----------------------------------------------------------------
//   -log web page requested    i.e. http://x.x.x.x/log
// ----------------------------------------------------------------


void handleLogpage() {

   log_system_message("log webpage requested");     

    // build the html for /log page

    String message = webheader(0);     // add the standard header

      message += "<P>\n";                // start of section
  
      message += "<br>SYSTEM LOG<br><br>\n";
  
      // list all system messages
      for (int i=LogNumber; i != 0; i--){
        message += system_message[i];
        if (i == LogNumber) {
          message += red + "  <-- most recent" + endcolour;
        }
        message += "<BR>\n";    // new line
      }
  
      // message += "<a href='/'>BACK TO MAIN PAGE</a>\n";       // link back to root page
  
      message += "<br>" + webfooter();     // add standard footer html
    

    server.send(200, "text/html", message);    // send the web page

}


// ----------------------------------------------------------------
//                      -invalid web page requested
// ----------------------------------------------------------------

void handleNotFound() {
  
  log_system_message("invalid web page requested");      
  String message = "File Not Found\n\n";
  message += "URI: ";
  message += server.uri();
  message += "\nMethod: ";
  message += ( server.method() == HTTP_GET ) ? "GET" : "POST";
  message += "\nArguments: ";
  message += server.args();
  message += "\n";

  for ( uint8_t i = 0; i < server.args(); i++ ) {
    message += " " + server.argName ( i ) + ": " + server.arg ( i ) + "\n";
  }

  server.send ( 404, "text/plain", message );
  message = "";      // clear variable
  
}



// ----------------------------------------------------------------
//        -request a web page and return reply as a string
// ----------------------------------------------------------------
//
//     parameters = ip address, page to request, port to use (usually 80)     e.g.   "alanesq.com","/index.htm",80


String requestpage(const char* ip, String page, int port){

  Serial.print("requesting web page: ");
  Serial.println(ip + page);
  //log_system_message("requesting web page");      

  // Connect to the site 
    WiFiClient client;
    if (!client.connect(ip, port)) {
      Serial.println("Connection failed :-(");
      log_system_message("web connection failed");      
      return "connection failed";
    }  
    Serial.println("Connected to host - sending request...");


    // request the page
    client.print(String("GET " + page + " HTTP/1.1\r\n") +
                 "Host: " + ip + "\r\n" + 
                 "Connection: close\r\n\r\n");
  
    Serial.println("Request sent - waiting for reply...");
  
    //Wait up to 5 seconds for server to respond then read response
    int i = 0;
    while ((!client.available()) && (i < 500)) {
      delay(10);
      i++;
    }
    
    String wpage="";    // reply stored here
    
    // Read the entire response up to 200 characters
    while( (client.available()) && (wpage.length() <= 200) ) {
      wpage += client.readStringUntil('\r');     
    }
    Serial.println("-----received web page--------");
    Serial.println(wpage);
    Serial.println("------------------------------");

    client.stop();    // close connection
    Serial.println("Connection closed.");

  return wpage;

}


// ----------------------------------------------------------------
//   -reboot web page requested        i.e. http://x.x.x.x/reboot  
// ----------------------------------------------------------------
//
//     note: this often fails if the esp has just been reflashed


void handleReboot(){

      String message = "Rebooting....";
      server.send(404, "text/plain", message);   // send reply as plain text

      // rebooting
        delay(500);          // give time to send the above html
        ESP.restart();   
        delay(5000);         // restart fails without this line

}


// --------------------------------------------------------------------------------------
//                                -wifi connection check
// --------------------------------------------------------------------------------------


void WIFIcheck() {
  
    if (WiFi.status() != WL_CONNECTED) {
      if ( wifiok == 1) {
        log_system_message("Wifi connection lost");          // log system message if wifi was ok but now down
        wifiok = 0;                                          // flag problem with wifi
      }
    } else { 
      // wifi is ok
      if ( wifiok == 0) {
        log_system_message("Wifi connection is back");       // log system message if wifi was down but now back
        wifiok = 1;                                          // flag wifi is now ok
      }
    }

}


//-----------------------------------------------------------------------------
//                contact the NTP pool and retrieve the time
//-----------------------------------------------------------------------------
//
// code from https://github.com/RalphBacon/No-Real-Time-Clock-RTC-required---use-an-NTP

time_t getNTPTime() {

  // Send a UDP packet to the NTP pool address
  Serial.print("\nSending NTP packet to ");
  Serial.println(timeServer);
  sendNTPpacket(timeServer);

  // Wait to see if a reply is available - timeout after X seconds. At least
  // this way we exit the 'delay' as soon as we have a UDP packet to process
  #define UDPtimeoutSecs 7
  int timeOutCnt = 0;
  while (NTPUdp.parsePacket() == 0 && ++timeOutCnt < (UDPtimeoutSecs * 10)){
    delay(100);
    yield();
  }

  // Is there UDP data present to be processed? Sneak a peek!
  if (NTPUdp.peek() != -1) {
    // We've received a packet, read the data from it
    NTPUdp.read(packetBuffer, NTP_PACKET_SIZE); // read the packet into the buffer

    // The time-stamp starts at byte 40 of the received packet and is four bytes,
    // or two words, long. First, extract the two words:
    unsigned long highWord = word(packetBuffer[40], packetBuffer[41]);
    unsigned long lowWord = word(packetBuffer[42], packetBuffer[43]);

    // combine the four bytes (two words) into a long integer
    // this is NTP time (seconds since Jan 1 1900)
    unsigned long secsSince1900 = highWord << 16 | lowWord;     // shift highword 16 binary places to the left then combine with lowword
    Serial.print("Seconds since Jan 1 1900 = ");
    Serial.println(secsSince1900);

    // now convert NTP time into everyday time:
    //Serial.print("Unix time = ");

    // Unix time starts on Jan 1 1970. In seconds, that's 2208988800:
    const unsigned long seventyYears = 2208988800UL;     // UL denotes it is 'unsigned long' 

    // subtract seventy years:
    unsigned long epoch = secsSince1900 - seventyYears;

    // Reset the interval to get the time from NTP server in case we previously changed it
    setSyncInterval(_resyncSeconds);
    NTPok = 1;       // flag NTP is currently connecting ok

    return epoch;
  }

  // Failed to get an NTP/UDP response
    Serial.println("No response");
    setSyncInterval(_resyncErrorSeconds);
    NTPok = 0;       // flag NTP not currently connecting

    return 0;
  
}


// --------------------------- E N D -----------------------------
