/**************************************************************************************************
 * 
 * Send emails from ESP8266 via Gmail - Dec19         see: https://www.youtube.com/watch?v=s913_7JXq4w
 * 
 *    include in main sketch if sending emails is required with command     #include "gmail.h"
 * 
 * 
 * This demo sketch will fail at the Gmail login unless your Google account has
 * set the following option:     Allow less secure apps: ON       
 *                               see:  https://myaccount.google.com/lesssecureapps
 *
 *
 *         Usage:     byte q = sendEmail("alan@alanesq.com","Test message","Hello\nThere");    
 *                    if (q==0) log_system_message("email sent ok" );
 *                    else log_system_message("Error sending email code=" + String(q) );  
 *                                         Wifi Stuff - Dec19
 *             
 *  
 **************************************************************************************************/
 

const char* _GMailServer = "smtp.gmail.com";

const int _httpsPort = 465;

const char* _mailUser = "youraddress@gmail.com";

const char* _mailPassword = "yourpassword";

const char* fingerprint = "39:30:82:89:74:59:3F:63:88:8D:03:C8:9E:4A:DF:00:5E:1F:02:B5";          // sha-1 fingerprint of smtp.gmail.com 


// Note: You can discover the fingerprint with this command in BASH
//                openssl s_client -connect smtp.gmail.com:587 -starttls smtp < /dev/null 2>/dev/null | openssl x509 -fingerprint -noout | cut -d'=' -f2



//  ----------------------------------------------------------------------------------------


#include <base64.h>
#include <WiFiClientSecure.h>
// #include <ESP8266WiFi.h>

WiFiClientSecure gmailClient;


//  ----------------------------------------------------------------------------------------



// Check response from SMTP server
byte response()
{
  // Wait for a response for up to X seconds
  int loopCount = 0;
  while (!gmailClient.available()) {
    delay(1);
    loopCount++;
    // if nothing received for 10 seconds, timeout
    if (loopCount > 10000) {
      gmailClient.stop();
      Serial.println(F("\r\nTimeout"));
      return 0;
    }
  }

  // Take a snapshot of the response code
  byte respCode = gmailClient.peek();
  while (gmailClient.available())
  {
    Serial.write(gmailClient.read());
  }

  if (respCode >= '4')
  {
    Serial.print("Failed in eRcv with response: ");
    Serial.print(respCode);
    return 0;
  }
  return 1;
}


// ----------------------------------------------------------------------------------------


// Function send a secure email via Gmail

byte sendEmail(String emailTo, String emailSubject, String emailBody)
{
  Serial.printf("Using fingerprint '%s'\n", fingerprint);
  gmailClient.setFingerprint(fingerprint); // not available in axTLS::WiFiClientSecure 4.2.2
  
  // port 465=SSL 587=TLS; 587 not available with library 4.2.2
  // this all needs Google security downgrading:
  // https://myaccount.google.com/lesssecureapps?utm_source=google-account&utm_medium=web
  
 /*
 * Gmail exposes port 465 for SMTP over SSL and port 587 for SMTP with STARTTLS.
 * The difference between these two is that SMTP over SSL first establishes a secure 
 * SSL/TLS connection and conducts SMTP over that connection, and SMTP with STARTTLS 
 * starts with unencrypted SMTP and then switches to SSL/TLS. 
 * See https://stackoverflow.com/questions/17281669/using-smtp-gmail-and-starttls
 */  
  Serial.println("Attempting to connect to: " + String(_GMailServer));
  if (gmailClient.connect(_GMailServer, _httpsPort)) {
    Serial.println(F("Connected"));
  } else {
    Serial.print(F("Connection failed (check fingerprint)"));
    return 1;
  }
  if (!response())
    return 2;

  Serial.println(F("Sending Extended Hello"));
  gmailClient.println("EHLO gmail.com");
  if (!response())
    return 3;

  // We're not using port 587 in this demo
  //Serial.println(F("STARTTLS"));
  //if (!response())
  //  return 4;
  //Serial.println(F("Sending EHLO"));
  //client.println("EHLO gmail.com");
  //if (!response())
  //  return 0;
  
  Serial.println(F("Sending auth login"));
  gmailClient.println("auth login");
  if (!response())
    return 5;

  Serial.println(F("Sending User"));
  // Change to your base64, ASCII encoded user
  gmailClient.println(base64::encode(_mailUser));
  if (!response())
    return 6;

  Serial.println(F("Sending Password"));
  // change to your base64, ASCII encoded password
  gmailClient.println(base64::encode(_mailPassword));
  if (!response())
    return 7;

  Serial.println(F("Sending From"));
  // your email address (sender) - MUST include angle brackets
  gmailClient.println("MAIL FROM: <" + String(_mailUser) + ">");
  if (!response())
    return 8;

  // change to recipient address - MUST include angle brackets
  Serial.println(F("Sending To"));
  gmailClient.println("RCPT To: <" + emailTo + ">");
  // Repeat above line for EACH recipient
  if (!response())
    return 9;

  Serial.println(F("Sending DATA"));
  gmailClient.println(F("DATA"));
  if (!response())
    return 10;

  Serial.println(F("Sending email"));
  // recipient address (include option display name if you want)
  gmailClient.println("To: <" + emailTo + ">");

  // change to your address
  gmailClient.println("From: " + String(_mailUser));
  gmailClient.println("Subject: " + emailSubject + "\r\n");
  gmailClient.println(emailBody + " \r\n");



  // IMPORTANT you must send a complete line containing just a "." to end the conversation
  // So the PREVIOUS line to this one must be a prinln not just a print
  gmailClient.println(F("."));
  if (!response())
    return 11;

  Serial.println(F("Sending QUIT"));
  gmailClient.println(F("QUIT"));
  if (!response())
    return 12;

  gmailClient.stop();
  Serial.println(F("Disconnected"));
  return 0;
}



// --------------------------- E N D -----------------------------
